/**
 * The type Base expression.
 */
public abstract class BaseExpression implements Expression {

}
